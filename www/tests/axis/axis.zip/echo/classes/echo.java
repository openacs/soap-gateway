/*
 * echo.java
 *
 * Created on December 16, 2002, 2:13 AM
 */

/**
 *
 * @author  William
 * @version 
 */

public class echo {


    /** Creates new echo */
    public echo() {
    }

    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) {
        
        // run in catch block
        try {

            // create locator
            org.openacs.interop.InteropLocator locator = new org.openacs.interop.InteropLocator();

            // specify service endpoint
            java.net.URL url = new java.net.URL(locator.getinteropSoapPortAddress());

            // uncomment the following line if you're using the MSSOAP Toolkit trace utility
            // url = new java.net.URL("http://localhost:8080/soap/action?service=interop");

            // create interop stub
            org.openacs.interop.InteropSoapBindingStub stub = new org.openacs.interop.InteropSoapBindingStub(url, null);

            // maintain session data; e.g., cookies for security
            stub.setMaintainSession(true);
        

            // login 
            stub.login("demo@byrnelitho.com", "user");		            


            // invoke and echo data
            String data = stub.echoString("Hello from AXIS SOAP stub!");

            
            // dump to output
            System.out.println(data);

            // logout
            stub.logout();

            
        } catch(Exception e) {
        
            // show error
            //e.printStackTrace();
	    System.out.println(e.toString());

            // report problem to env	
	    System.exit(1);
        }

        // report ok to env	
	System.exit(0);
    }

}
