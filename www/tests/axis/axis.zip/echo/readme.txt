                        
                        Using AXIS to connect to SOAP-GATEWAY                  
                                     Echo Test

                                   William Byrne  
                               WilliamB@ByrneLitho.com
                                 January 19, 2003



Overview
--------

The contents of this axis folder and its subdirectories provides the source code,
libraries, and batch files to test a basic connection to the soap-gateway package
installed on an OpenACS server. 

Installation
------------

In order for the test to succeed, the soap-gateway must be successfully installed 
on a OpenACS server. Refer to the installation notes
    
     http://my.server.com/doc/soap-gateway/
      - or -
     %openacs-install-path%/packages/soap-gateway/www/doc/index.adp

Extract all files from archive to any directory maintaining directory hierarchy
specified within archive. 

The archive includes the necessary AXIS libraries v1.0, XERCES v1.4.4, and 
Servlet.jar from the jakarta dist. v4.1.18. If you wish to download the complete
SDK's, go to:

   AXIS         http://xml.apache.org/axis/
   XERCES       http://xml.apache.org/xerces-j/
   Servlet.jar  http://jakarta.apache.org


The soap-gateway package is subject to the GNU Lesser General Public License. See:
     http://your.server/doc/soap-gateway/license.txt
      - or -
     %openacs-install-path%/packages/soap-gateway/www/doc/license.txt


Building
--------

In the root folder of the archive, you'll find batch files that can be used
to build and run the 'echo' test. Most of the files should run without problems.
The file 'build-workspace-stubs.cmd' specifies a bogus URL that will not work
unless you modify your hosts table. Instead, edit the file and change the line:

	set WSDL=http://my.server.com/soap/wsdl?service=workspace

so the server is properly referenced. In other words, change my.server.com to
the name of your OpenACS server. There must also be soap-gateway subsite on your 
server named 'soap'. You can use a different subsite name; however, the subsite
'soap' is referenced in a few places in documentation and tests. Refer to the
installation section of the soap-gateway doc described above for more information.


Open a console to the base installation path and execute 'all.cmd'. The 'all' batch
file invokes a handful of other batch files and performs some error checking. It
contains some information about what to do in the event of errors.

Execute 'run-echo.cmd' to make a SOAP call into your OpenACS server. 

Notes
------

The 'echo' test referenced in this test project uses the 'interop' SOAP service.
The 'interop' service provides basic 'echo' tests. 

The 'echo' test simply log's into OpenACS and performs an echo test returning the
same data passed to the server. 

More information regarding the 'interop' service is available in the 
soap-gateway documents referred to above.

//eof
















